import pandas as pd
import openpyxl as op

def read_save():
    balancete = pd.read_csv("./balancete.csv")
    balancete.to_excel("balancete.xlsx")
    novo_balancete = op.load_workbook("balancete.xlsx")    
    novo_balancete.save("novo_balancete.xlsx")