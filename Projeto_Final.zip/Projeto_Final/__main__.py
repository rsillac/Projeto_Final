import requests
import leitor_conv


def page_reader(url: str) -> requests.models.Response:
    pagina = requests.get(url)
    return pagina

def grava_pagina_web(resposta: requests.models.Response) -> None:
    dados = open('balancete.csv', 'wb')
    for texto in resposta.iter_content(1048576):
        dados.write(texto)
    dados.close()

def main():
    endereco = "http://dados.tce.rs.gov.br/dados/municipal/balancete-despesa/2022.csv"
    politica = page_reader(endereco)
    grava_pagina_web(politica)
    leitor_conv.read_save()
     

if __name__ == '__main__':
    main()